import React from 'react'
import Estilo from '../estilo'
import {Text, react} from 'react-native'

import Produtos from './produtos'

export default props => {
    return (
        <>
            <Text style={Estilo.txtG}>Lista de Produtos</Text>
            {Produtos.map(p => {
                return <Text style={Estilo.txtM} key={p.id}> {p.id} - {p.nome} - {p.preco} </Text>
            })}
        </>
    )
}