export default [
    {id: 1, nome: 'LOUS 2', preco: 319.99},
    {id: 2, nome: 'Caderno', preco: 9.99},
    {id: 3, nome: 'Lapis', preco: 1.99},
    {id: 4, nome: 'Folha', preco: 0.99},
    {id: 5, nome: 'Mochila', preco: 19.99},
]