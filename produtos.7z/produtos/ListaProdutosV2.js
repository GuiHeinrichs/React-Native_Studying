import React from 'react'
import Estilo from '../estilo'
import {Text, FlatList} from 'react-native'

import Produtos from './produtos'

export default props => {

    const RenderProducts = ({ item:p }) => {
        return <Text style={Estilo.txtM}>{p.id}) {p.nome}: {p.preco}.</Text>
    }
    return (
        <>
            <Text style={Estilo.txtG}>Lista de Produtos V2</Text>
            <FlatList
                data={Produtos}
                keyExtractor={i => `${i.id}`}
                renderItem={RenderProducts}
            />
        </>
    )
}