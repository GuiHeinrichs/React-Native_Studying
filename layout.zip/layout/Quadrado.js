import React from 'react'
import {View, StyleSheet} from 'react-native'


export default props => {
    return (
        <View style={{
            height:70,
            width:70,
            backgroundColor: props.color || '#000'
        }}/>
            
        
    )
}
