import React from 'react'
import {View, SafeAreaView, StyleSheet} from 'react-native'
import Quadrado from './Quadrado'


export default props => {
    return (
        <SafeAreaView style={style.FlexV1}>
            <Quadrado color='#f40312'/>
            <Quadrado color='#f0b114'/>
            <Quadrado color='#30b114'/>
            <Quadrado color='#80b114'/>        
        </SafeAreaView>
    )
}

const style = StyleSheet.create({
    FlexV1: {
        flex: 1,
        justifyContent: 'space-between',
        backgroundColor: '#000'
        
    }
})