import React from 'react'
import {View, SafeAreaView, StyleSheet} from 'react-native'
import Quadrado from './Quadrado'


export default props => {
    return (
        <View style={style.FlexV3}>
            <View style={style.V1}/>  
            <View style={style.V2}/>  
            <View style={style.V3}/>            
        </View>
    )
}

const style = StyleSheet.create({
    FlexV3: {
        flexGrow: 1,
        width: 100,
        backgroundColor: '#000'
    },
    V1:{
        flex: 2,
        backgroundColor: '#a135'
    },
    V2:{
        flex: 3,
        backgroundColor: '#234'
    },
    V3: {
        flex: 4,
        backgroundColor: '#456'
    }
})