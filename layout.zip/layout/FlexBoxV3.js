import React from 'react'
import {View, SafeAreaView, StyleSheet} from 'react-native'
import Quadrado from './Quadrado'


export default props => {
    return (
        <SafeAreaView style={style.FlexV3}>
            <Quadrado color='#f40312'/>
            <Quadrado color='#f0b114'/>
            <Quadrado color='#30b114'/>
            <Quadrado color='#80b114'/>        
        </SafeAreaView>
    )
}

const style = StyleSheet.create({
    FlexV3: {
        height: 350,
        width: '100%',
        flexDirection: "row",
        justifyContent: "space-evenly",
        alignItems: 'center',
        backgroundColor: '#000'
        
    }
})